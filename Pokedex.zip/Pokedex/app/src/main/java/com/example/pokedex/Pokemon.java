package com.example.pokedex;

public class Pokemon {
    private String name;
    private String url;
    private boolean caught;

    Pokemon(String name, String url, boolean caught) {
        this.name = name;
        this.caught = caught;
        this.url = url;
    }
    Pokemon(String name, String url) {
        this.name = name;
        this.caught = false;
        this.url = url;
    }
    Pokemon(String name)
    {
        this.name = name;
        this.caught = false;
        this.url = "";
    }

    public String getName()
    {
        return this.name;
    }

    public String getUrl()
    {
        return this.url;
    }

    public boolean getCaught()
    {
        return this.caught;
    }
    public void Catch()
    {
        if (this.caught == true)
        {
            this.caught = false;
        }
        else
        {
            this.caught = true;
        }
    }
}
