package com.example.pokedex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.JsonWriter;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.reflect.TypeToken;

import android.view.View;
import android.widget.Toast;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class PokemonActivity extends AppCompatActivity {
    private SharedPreferences sharedPreferences;
    private static final String ALL_POKEMON_KEY = "ALL_POKEMON";
    private TextView nameTextView;
    private TextView numberTextView;
    private String url;
    private View buttonView;
    private TextView type1TextView;
    private RequestQueue requestQueue;
    private TextView type2TextView;
    private ImageView pokeImage;
    private TextView pokeDesc;
    Map<String, String> caughtPokemon = new HashMap<>();
    String pokeName;
    boolean first = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokemon);


        requestQueue = Volley.newRequestQueue(getApplicationContext());
        url = getIntent().getStringExtra("url");
        nameTextView = findViewById(R.id.pokemon_name);
        numberTextView = findViewById(R.id.pokemon_number);
        type1TextView = findViewById(R.id.pokemon_type1);
        type2TextView = findViewById(R.id.pokemon_type2);
        buttonView = findViewById(R.id.button_send);
        pokeDesc = findViewById(R.id.pokemon_desc);
        pokeImage = findViewById(R.id.pokemon_pic);
        load(buttonView);
    }


    public void toggleCatch(View view) {
        Button button = (Button) view;
        Boolean caught = getPreferences(Context.MODE_PRIVATE).getBoolean(pokeName, false);
        if (!caught.booleanValue()) {

            getPreferences(Context.MODE_PRIVATE).edit().putBoolean(pokeName, true).commit();
            Toast.makeText(this, pokeName + " was caught!", Toast.LENGTH_SHORT).show();
            button.setBackgroundColor(Color.RED);
            button.setText("Release");
            Log.e("toggleCatch", pokeName + "was caught");

        } else {
            getPreferences(Context.MODE_PRIVATE).edit().putBoolean(pokeName, false).commit();
            Toast.makeText(this, pokeName + " was released :(", Toast.LENGTH_SHORT).show();
            button.setText("Catch");
            button.setBackgroundColor(Color.GREEN);
            Log.e("toggleCatch", pokeName + "was released");
        }

    }

    private void firstLoad(Button button) {
        Boolean caught = getPreferences(Context.MODE_PRIVATE).getBoolean(pokeName, false);
        if (!caught.booleanValue()) {
            button.setText("Catch");
            button.setBackgroundColor(Color.GREEN);
            Log.e("firstLoad", "Loading button when the pokemon hasn't been caught");
        } else {
            button.setText("Release");
            button.setBackgroundColor(Color.RED);
            Log.e("firstLoad", "Loading button when the pokemon hasn't been caught");
        }
    }

    private class DownloadSpriteTask extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... strings) {
            try {
                URL url = new URL(strings[0]);
                Bitmap b = BitmapFactory.decodeStream(url.openStream());
                b = Bitmap.createScaledBitmap(b, 500, 500, false);
                return b;
            } catch (IOException e) {
                Log.e("cs50", "Download sprite error", e);
                return null;
            }
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            pokeImage.setImageBitmap(bitmap);
        }
    }

        public void load(View view) {
            final Button button = (Button) view;
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {

                        pokeName = response.getString("name");
                        nameTextView.setText(pokeName);
                        JSONObject urls = response.getJSONObject("sprites");
                        String url = urls.getString("front_default");
                        JSONObject descs = response.getJSONObject("species");
                        String descURL = descs.getString("url");
                        JsonObjectRequest request1 = new JsonObjectRequest(Request.Method.GET, descURL, null,  new Response.Listener<JSONObject>()
                        {
                            @Override
                            public void onResponse(JSONObject response) {
                                try
                                {
                                    JSONArray flavorTextEntries = response.getJSONArray("flavor_text_entries");
                                    JSONObject flavorText = flavorTextEntries.getJSONObject(0);
                                    String desc = flavorText.getString("flavor_text");
                                    System.out.println(desc);
                                    pokeDesc.setText(desc);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }

                        }
                        , new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Log.e("cs50", "Pokemon desc error");
                            }
                        }
                        );
                        requestQueue.add(request1);

                        int id = response.getInt("id");
                        if (!getPreferences(Context.MODE_PRIVATE).getAll().containsKey(pokeName)) {
                            caughtPokemon.put(pokeName, "false");
                        }
                        numberTextView.setText(String.format("#%03d", id));

                        JSONArray typeEntries = response.getJSONArray("types");
                        for (int i = 0; i < typeEntries.length(); i++) {
                            JSONObject typeEntry = typeEntries.getJSONObject(i);
                            int slot = typeEntry.getInt("slot");
                            String type = typeEntry.getJSONObject("type").getString("name");
                            if (slot == 1) {
                                type1TextView.setText(type);
                            } else if (slot == 2) {
                                type2TextView.setText(type);
                            }
                        }
                        firstLoad(button);
                        new DownloadSpriteTask().execute(url);


                    } catch (JSONException e) {
                        Log.e("cs50", "Pokemon json error", e);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("cs50", "Pokemon list error");
                }
            }
            );

            requestQueue.add(request);
        }

    }
